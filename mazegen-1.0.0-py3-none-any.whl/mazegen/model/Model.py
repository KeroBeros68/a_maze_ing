"""
Configuration model for maze generation.

This module defines the Pydantic configuration model that validates
maze generation parameters from the config.txt file.

The model ensures:
- Valid maze dimensions (width and height)
- Valid entry and exit coordinates within bounds
- Entry and exit are different points
- Output file name is valid
- Algorithm name is valid

Classes:
    ConfigModel: Pydantic BaseSettings model for maze configuration
"""

from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field, model_validator, field_validator
from typing import Optional, Tuple


class ConfigModel(BaseSettings):
    """Pydantic configuration model for maze generation settings.

    Validates and loads maze generation parameters from config.txt file.
    Ensures all configuration values are within valid ranges and
    coordinates are consistent.

    Attributes:
        WIDTH: Width of the maze (2-200)
        HEIGHT: Height of the maze (2-200)
        ENTRY: Entry point coordinates (x, y)
        EXIT: Exit point coordinates (x, y)
        OUTPUT_FILE: Path to output file for generated maze (4-15 chars)
        PERFECT: Whether to generate a perfect maze (no loops, default: True)
        ALGORITHM: Maze generation algorithm name ("backtracking" or "prim")
        SEED: Random seed for reproducible generation (optional, max 100 chars)
        MODE_GEN: Generation mode ("static" or "animated", default: "static")
        DISPLAY_MODE: Display mode ("basic", "tty", or "mlx", default: "basic")
        STAMP_TYPE: Stamp design type ("42vanilla" or "42custom",
                    default: "42vanilla")
    """
    model_config = SettingsConfigDict(env_file="config.txt")

    WIDTH: int = Field(..., ge=2, le=200, description="Width of the maze")
    HEIGHT: int = Field(..., ge=2, le=200, description="Height of the maze")
    ENTRY: Tuple[int, int] = Field(..., description="Entry coordinates (x, y)")
    EXIT: Tuple[int, int] = Field(..., description="Exit coordinates (x, y)")
    OUTPUT_FILE: str = Field(
        ..., min_length=4, max_length=15, description="Output file name"
    )
    PERFECT: bool = Field(default=True, description="Generate a perfect maze")
    ALGORITHM: str = Field(
        default="backtracking", description="Maze generation algorithm to use"
    )
    SEED: Optional[str] = Field(
        default=None,
        min_length=0,
        max_length=100,
        description="Seed generation",
    )
    MODE_GEN: str = Field(
        default="static",
        description="Generation mode: " "'static' or 'animated'",
    )
    DISPLAY_MODE: str = Field(
        default="basic", description="Display mode (basic, tty, mlx)"
    )
    STAMP_TYPE: str = Field(
        default="42vanilla",
        description="Stamp design type (42vanilla, 42custom)"
    )

    @field_validator("ALGORITHM", "MODE_GEN",
                     "DISPLAY_MODE", "STAMP_TYPE", mode="before")
    @classmethod
    def lowercase_fields(cls, v: str) -> str:
        """Convert string fields to lowercase."""
        if isinstance(v, str):
            return v.lower()
        return v

    @model_validator(mode="after")
    def validate_entry_exit(self) -> "ConfigModel":
        """
        Validate entry and exit coordinates.

        Ensures that:
        - Entry and exit coordinates are non-negative
        - Entry and exit coordinates are different
        - Coordinates are within maze bounds (width and height)
        - Entry and exit are on the external border of the maze

        Returns:
            ConfigModel: The validated configuration model

        Raises:
            ValueError: If any coordinate validation fails
        """
        x1, y1 = self.ENTRY
        x2, y2 = self.EXIT

        # Check coordinates are not negative
        if x1 < 0 or y1 < 0 or x2 < 0 or y2 < 0:
            raise ValueError("Entry and Exit coordinates must be non-negative")

        # Check they are different
        if self.ENTRY == self.EXIT:
            raise ValueError(
                "Exit coordinates cannot be the same as Entry coordinates"
            )

        # Check they are within bounds
        if x1 >= self.WIDTH or x2 >= self.WIDTH:
            raise ValueError(
                f"Entry or Exit X coordinate exceeds width ({self.WIDTH})"
            )
        if y1 >= self.HEIGHT or y2 >= self.HEIGHT:
            raise ValueError(
                f"Entry or Exit Y coordinate exceeds height ({self.HEIGHT})"
            )

        return self

    @model_validator(mode="after")
    def validate_maze_size_for_stamp(self) -> "ConfigModel":
        """Validate that the maze is large enough to fit the selected stamp.

        Ensures that the maze dimensions meet the minimum size requirements
        for the chosen stamp design.

        Returns:
            ConfigModel: The validated configuration model

        Raises:
            ValueError: If the maze is too small for the selected stamp type
        """
        x = self.WIDTH
        y = self.HEIGHT
        stamp = self.STAMP_TYPE

        if stamp == "42vanilla" and (x < 9 or y < 9):
            raise ValueError(
                "Maze too small for that stamp"
            )

        return self
